</div> <!--/wrapper-->

<div id="footer">
	<footer id="colophon" role="contentinfo">
	<p><a href="/">HOME</a> / <a href="/about-us/">ABOUT PGC3</a>  /  <a href="/membership/">MEMBERS</a>  /  <a href="/news">NEWS</a>  /  <a href="/forum">FORUM</a></p>
	<p>(c) Portland Geek Council of Commerce & Culture  /  all rights reserved</p>
			<?php
				/* A sidebar in the footer? Yep. You can can customize
				 * your footer with three columns of widgets.
				 */
				get_sidebar( 'footer' );
			?>

	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>


</body>
</html>
